<?php
include $_SERVER["DOCUMENT_ROOT"].'/config.php';
include $_SERVER["DOCUMENT_ROOT"].'/functions.php';
echo 'Database host: '.DB_SERVER.'<br/>';
echo 'Email: '.$mFrom.'<br/>';
echo $_SERVER['PHP_SELF'];
echo "<br>";
echo $_SERVER['SERVER_NAME'];
echo "<br>";
echo $_SERVER['HTTP_HOST'];
echo "<br>";
// echo $_SERVER['HTTP_REFERER'];
echo "<br>";
echo $_SERVER['HTTP_USER_AGENT'];
echo "<br>";
echo $_SERVER['SCRIPT_NAME'];
?>